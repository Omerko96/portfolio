// Preloader Animation
$(document).ready(function() {

  setTimeout(function(){
      $('body').addClass('loaded');
  }, 3000);

});